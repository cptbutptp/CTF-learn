# File Monitor (beta)

```
Usage:
	python file_monitor.py [WATCH_PATH] [LOG_PATH]
Example:
	python file_monitor.py /var/www/html /var/log/my_log
```
