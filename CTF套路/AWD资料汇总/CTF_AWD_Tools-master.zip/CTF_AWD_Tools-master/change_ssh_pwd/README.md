# Auto Change SSH password

```
Usage : 
	python change_ssh_pwd.py [FILENAME]
Example :
	python change_ssh_pwd.py target.txt
```
