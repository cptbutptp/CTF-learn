document.writeln("<script async src=\"//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js\"></script>");
document.writeln("<!-- question-side -->");
document.writeln("<ins class=\"adsbygoogle\"");
document.writeln("     style=\"display:inline-block;width:970px;height:90px\"");
document.writeln("     data-ad-client=\"ca-pub-7090564139599510\"");
document.writeln("     data-ad-slot=\"9002503316\"></ins>");
document.writeln("<script>");
document.writeln("(adsbygoogle = window.adsbygoogle || []).push({});");
document.writeln("</script>");