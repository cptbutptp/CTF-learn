#coding:utf-8
import requests
fast_session = requests.Session()
print fast_session.ppost(url,data={-----------------------------1220307824291
Content-Disposition: form-data; name="name"

flag1
-----------------------------1220307824291
Content-Disposition: form-data; name="category"

flag1
-----------------------------1220307824291
Content-Disposition: form-data; name="desc"

flag1
-----------------------------1220307824291
Content-Disposition: form-data; name="value"

100
-----------------------------1220307824291
Content-Disposition: form-data; name="key"

flag{123}
-----------------------------1220307824291
Content-Disposition: form-data; name="key_type[0]"

0
-----------------------------1220307824291
Content-Disposition: form-data; name="files[]"; filename=""
Content-Type: application/octet-stream


-----------------------------1220307824291
Content-Disposition: form-data; name="nonce"

f227f598be5f2398c93d501104205a01345166f8cd63dc0da3ce356194ecba4d863e6ae258bfae49de5325a2a6cb156dba24566064f46789b542a5c71c342d10
-----------------------------1220307824291
Content-Disposition: form-data; name="chaltype"

0
-----------------------------1220307824291--)。content