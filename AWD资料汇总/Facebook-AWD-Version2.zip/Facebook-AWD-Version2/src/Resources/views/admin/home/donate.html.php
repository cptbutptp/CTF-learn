<?php
/**
 * Facebook AWD Template.
 *
 * @author PopCode (Alexandre Hermann) [hermann.alexandre@ahwebev.fr]
 */
?>
<div class="facebookAWD">
    <p>
        <a class="btn btn-default btn-block" role="button" href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=ZQ2VL33YXHJLC"><?php echo $this->_('Pay me a coffee'); ?> <span class="glyphicon glyphicon-heart"></span></a>
    </p>
</div>
