<?php
/**
 * Facebook AWD Template.
 *
 * @author PopCode (Alexandre Hermann) [hermann.alexandre@ahwebev.fr]
 */
?>
<div class="facebookAWD">
    <p>
        <a class="btn btn-default btn-xs btn-block" role="button" href="http://www.facebook-awd.com"><?php echo $this->_('Learn more'); ?></a>
        <a class="btn btn-default btn-xs btn-block" role="button" href="http://www.facebook-awd.com"><?php echo $this->_('Documentation'); ?></a>
    </p>
</div>
