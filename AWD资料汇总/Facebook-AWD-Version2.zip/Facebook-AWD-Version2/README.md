Facebook AWD [![Build Status](https://travis-ci.org/Facebook-AWD/Facebook-AWD.svg?branch=Version2)](https://travis-ci.org/Facebook-AWD/Facebook-AWD)
=========

Facebook AWD is a wordpress extension that adds facebook functions on your website.

Installation
--------------

```sh
cd wp-content/plugins
git clone git@github.com:Facebook-AWD/Facebook-AWD.git facebook-awd
cd facebook-awd
chmod +x ./bin/install.sh
./bin/install.sh
```

##### Requires php > 5.4

http://www.facebook-awd.com